# 导入所需的库
from sklearn.model_selection import train_test_split  # 数据集拆分
from sklearn.ensemble import RandomForestRegressor  # 随机森林回归器
import shap  # SHAP库用于模型解释
import numpy as np  # 数值计算
import matplotlib.pyplot as plt  # 绘图
from matplotlib import cm, colors  # 颜色映射
from mpl_toolkits.axes_grid1 import make_axes_locatable  # 辅助坐标轴布局
import pandas as pd  # 数据处理

# 设置全局字体和样式
plt.rcParams['font.family'] = ['Arial']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 16

# 读取 Excel 文件并清理列名
df = pd.read_excel(r"D:\~~~~\run_data.xlsx", engine='openpyxl')
df.columns = df.columns.str.strip()  # 去除列名空格，避免 key error

# 设置特征和标签
X = df.drop(columns=['target']).values
y = df['target'].values
feature_names = df.drop(columns=['target']).columns.tolist()

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X,
                                                    y,
                                                    test_size=0.2,
                                                    random_state=5)

# 训练随机森林回归模型
regressor = RandomForestRegressor(n_estimators=100,
                                  random_state=4).fit(X_train, y_train)

# 构建SHAP解释器，计算训练集的SHAP值
explainer = shap.TreeExplainer(regressor,
                               X_train,
                               feature_names=feature_names)
shap_values = explainer(X_train, check_additivity=False)  # 关闭 additivity

mean_shap_vals = np.abs(shap_values.values).mean(axis=0)
feature_importance = list(zip(feature_names, mean_shap_vals))
feature_importance_sorted = sorted(feature_importance, key=lambda x: x[1], reverse=True)

print("\nMean(|SHAP|) for each feature:")
for name, val in feature_importance_sorted:
    print(f"{name}: {val:.6f}")
# #
# 创建主图（条形图）
fig, ax1 = plt.subplots(figsize=(6, 6))
max_display = 16  # 显示前15个特征
cmap1 = shap.plots.colors.red_blue  # 颜色映射
shap.plots.bar(shap_values, max_display=max_display, show=False, ax=ax1)  # 绘制SHAP条形图

ind = max_display
for p in ax1.patches:
    p.set_color(cmap1(ind / max_display))  # 设置每个条的颜色
    ind -= 1
for t in ax1.texts:
    t.set_visible(False)  # 隐藏默认文本
ax1.tick_params(axis='x', pad=1, labelsize=14)
ax1.tick_params(axis='y', colors='black', length=3, left=True, labelsize=14)
ax1.set_xlim(27000, 0)  # x轴范围
#ax1.set_ylim(1.5, max_display+0.4)  # y轴范围
ax1.spines['left'].set_visible(True)
ax1.spines['right'].set_visible(False)

# 创建极坐标环形图
width = 0.45

# ax2 = fig.add_axes([0.8 - width, 0.5 - width, width, width], polar=True)
ax2 = fig.add_axes([0.05, 0.5 - width, width, width], polar=True)

# 计算特征重要性归一化后的数据
data = np.abs(shap_values.values).mean(axis=0)
data = (data - data.min()) / (data.max() - data.min())
data_sort = (np.sort(data) * 100)
data_percent = data_sort / data_sort.sum() * 100
data_percent = data_percent[-max_display:]
data_percent_norm = data_percent / data_percent.sum()
categories = len(data_percent)

# 计算极坐标角度和底部高度
theta = np.linspace(0.5 * np.pi, 2.5 * np.pi, categories, endpoint=False)
bottom = np.linspace(0.09, 0.08, categories)

# 绘制主环形条形图
bars1 = ax2.bar(
    theta,
    height=[data_percent_norm[i] + 0.04 for i in range(categories)],
    width=np.pi * 2 / categories,
    bottom=0,
    color=cmap1(np.linspace(0, 1, categories + 1)),
    edgecolor='white',
    align='edge',
)

# 绘制底部浅色环形条1
color2 = ['ghostwhite', 'whitesmoke']
cmap2 = colors.ListedColormap(color2, N=max_display)
bars2 = ax2.bar(
    theta,
    height=0.03,
    width=np.pi * 2 / categories,
    bottom=0,
    color=cmap2.colors,
    edgecolor='white',
    align='edge',
)

# 计算标签角度
theta_new = np.append(theta, 2.5 * np.pi)
theta_label = [(theta_new[i + 1] + val) / 2 for i, val in enumerate(theta)]

# 添加百分比标签
for angle, val, r, b in zip(theta_label, data_percent, bottom, data_percent_norm):
    if val > 1:
        label_radius = b + r
        ax2.text(
            angle,
            label_radius,
            f'{round(val, 2)}%',
            ha='center',
            va='center',
            fontsize=10,
        )

# 极坐标图美化设置
ax2.set_xticklabels([])
ax2.set_yticklabels([])
ax2.grid(False)
ax2.spines[:].set_visible(False)
ax2.set_facecolor('none')

# 添加主图右侧的颜色条
divider = make_axes_locatable(ax1)
cax = divider.append_axes("right", size="4%", pad=0.1)
cax.tick_params(length=0, pad=1)
cb = plt.colorbar(mappable=cm.ScalarMappable(cmap=cmap1),
                  cax=cax,
                  orientation='vertical')
cb.set_ticks(ticks=[0.065, 0.98], labels=['Low', 'High'], rotation=90)
cb.outline.set_linewidth(0)

# 保存 bar + polar 图为 PDF
plt.savefig(r"D:\桌面文件\2.pdf", format='pdf', bbox_inches='tight')
plt.show()

# 绘制 SHAP beeswarm 图
shap.plots.beeswarm(shap_values, max_display=15, show=False)
plt.savefig(r"D:\桌面文件\3.pdf", format='pdf', bbox_inches='tight')
plt.show()
