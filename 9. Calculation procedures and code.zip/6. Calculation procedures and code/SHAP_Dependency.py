#推荐使用jupyter运行，如再其他环境中运行其自行配置环境
#Part 1
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['axes.unicode_minus'] = False
import warnings
# 忽略所有警告
warnings.filterwarnings("ignore")
df = pd.read_excel(r"D:\~~~~~\run_data_loss.xlsx", engine="openpyxl")
print(df.head())

#Part 2
from sklearn.model_selection import train_test_split
# 划分特征和目标变量
X = df.drop(['target'], axis=1)
y = df['target']
# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=4,
    stratify=df['target']
)

from sklearn.model_selection import GridSearchCV, KFold
import xgboost as xgb

# 定义XGBoost模型
xgb_model = xgb.XGBClassifier(random_state=42)
# 定义超参数网格
param_grid = {
    'max_depth': [3, 6, 9],
    'learning_rate': [0.01, 0.1, 0.2],
    'n_estimators': [100, 200],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.8, 1.0],
}
# 使用KFold进行k折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
grid_search = GridSearchCV(
    estimator=xgb_model,
    param_grid=param_grid,
    scoring='roc_auc',    # 使用AUC评估模型
    cv=kf,                # K折交叉验证
    verbose=1,            # 输出进度
    n_jobs=-1             # 使用所有可用的CPU核心
)
# 训练模型
grid_search.fit(X_train, y_train)
# 输出最佳参数组合
print("最佳超参数:", grid_search.best_params_)
best_model = grid_search.best_estimator_

#Part 3
import shap
explainer = shap.TreeExplainer(best_model)
shap_values = explainer.shap_values(X_test)
shap_values_df = pd.DataFrame(shap_values, columns=X_test.columns)
shap_values_df.head()

#Part 4
# LOWESS + 95% CI 多子图绘制
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from statsmodels.nonparametric.smoothers_lowess import lowess
from scipy.interpolate import interp1d

# —— 可选：进一步减小 PDF 体积/内存 ——
mpl.rcParams['pdf.compression'] = 9           # 压缩 PDF
mpl.rcParams['agg.path.chunksize'] = 10000    # 超长路径分块，避免巨大向量对象内存暴涨

def plot_lowess_with_ci(
    X_test, shap_values_df, features,
    ncols=4, nrows=5,                   # 子图网格
    lowess_frac=0.4,
    n_bootstraps=100,
    random_seed=4,
    save_as_pdf=False,
    pdf_path="lowess_plots.pdf",
    dpi=400,
    use_tight=True
):
    """
    绘制若干特征的 SHAP-值散点 + LOWESS 趋势 + 95% CI。
    已做：统一大字号、散点/置信带栅格化以降低 PDF 内存占用。
    """
    # ========= 统一放大字体（全局） =========
    FS_BASE   = 25  # 全局默认字号
    FS_LABEL  = 25  # 坐标轴标签
    FS_TICK   = 25  # 坐标轴刻度
    FS_LEGEND = 20  # 图例
    FS_ANN    = 20  # R² 角标
    FS_CBAR_L = 22  # 颜色条标题
    FS_CBAR_T = 22  # 颜色条刻度

    plt.rcParams.update({
        "font.family": "Arial",
        "font.size":   FS_BASE,
        "axes.unicode_minus": False
    })
    # ======================================

    if len(features) == 0:
        print("No features to plot.")
        fig, ax = plt.subplots(figsize=(7.5, 6.0))
        ax.text(0.5, 0.5, "No features to plot", ha='center', va='center', fontsize=FS_BASE)
        plt.show()
        return

    np.random.seed(random_seed)

    # 自定义散点颜色映射（示例配色）
    colors_for_cmap = ['#ADD8E6', '#D8BFD8', '#DA70D6', '#FF00FF']
    custom_cmap = LinearSegmentedColormap.from_list("my_custom_cap", colors_for_cmap)

    # 画布尺寸：每格略放大，适配大字号
    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(ncols * 7.0, nrows * 6.0))
    axes = axes.flatten()

    for idx, feature_to_plot in enumerate(features):
        ax = axes[idx]

        # —— 取该特征 X 与对应 SHAP 值，并剔除无效值 ——
        X_data_orig = X_test[feature_to_plot].values
        Y_data_orig = shap_values_df[feature_to_plot].values
        valid = np.isfinite(X_data_orig) & np.isfinite(Y_data_orig)
        X_data = X_data_orig[valid]
        Y_data = Y_data_orig[valid]

        if len(X_data) < 2:
            ax.text(0.5, 0.5, f"Not enough data: {feature_to_plot}",
                    ha='center', va='center', fontsize=FS_BASE)
            ax.set_axis_off()
            continue

        # —— 主 LOWESS 拟合 ——
        order = np.argsort(X_data)
        X_sorted = X_data[order]
        Y_sorted = Y_data[order]
        main_fit = lowess(Y_sorted, X_sorted, frac=lowess_frac, it=0)

        # —— 拟合结果去重，并构造插值函数用于 R² 计算 ——
        ux, uidx = np.unique(main_fit[:, 0], return_index=True)
        uy = main_fit[uidx, 1]
        f_interp = None
        if len(ux) > 1:
            f_interp = interp1d(ux, uy, kind='linear', fill_value="extrapolate")

        # —— R²（相对 LOWESS） ——
        ss_res = np.sum((Y_sorted - f_interp(X_sorted))**2)
        ss_tot = np.sum((Y_sorted - np.mean(Y_sorted))**2)
        r2_lowess = 1.0 - (ss_res / ss_tot) if ss_tot > np.finfo(float).eps else 0.0

        # —— 自助法估计 95% CI（可适当降低 n_bootstraps 缓解性能） ——
        ci_lower = ci_upper = None
        if len(X_data) > 1 and n_bootstraps > 0:
            preds = []
            x_eval = np.linspace(X_data.min(), X_data.max(), 100)
            for _ in range(n_bootstraps):
                idx_boot = np.random.choice(len(X_data), len(X_data), replace=True)
                xb, yb = X_data[idx_boot], Y_data[idx_boot]
                o = np.argsort(xb)
                xb, yb = xb[o], yb[o]
                if len(xb) < 2:
                    continue
                fit_b = lowess(yb, xb, frac=lowess_frac, it=0)
                ux_b, uidx_b = np.unique(fit_b[:, 0], return_index=True)
                if len(ux_b) > 1:
                    yb_interp = np.interp(x_eval, ux_b, fit_b[uidx_b, 1])
                    preds.append(yb_interp)
            if preds:
                preds = np.vstack(preds)
                ci_lower = np.percentile(preds, 2.5, axis=0)
                ci_upper = np.percentile(preds, 97.5, axis=0)

        # —— 绘制：散点（栅格化以降低 PDF 内存） ——
        ax.set_rasterization_zorder(1.5)  # zorder ≤ 1.5 的元素将被栅格化
        sc = ax.scatter(
            X_data, Y_data,
            s=60, c=X_data, cmap=custom_cmap, alpha=0.78,
            edgecolor='none', zorder=2, rasterized=True
        )

        # —— 主趋势线（保留向量，线更粗） ——
        ax.plot(main_fit[:, 0], main_fit[:, 1],
                color='#A52A2A', linewidth=3.0, label='Trendline (LOWESS)', zorder=3)
        # —— 置信区间带（栅格化） ——
        if ci_lower is not None and ci_upper is not None:
            ax.fill_between(
                x_eval, ci_lower, ci_upper,
                color='salmon', alpha=0.35,
                label='95% CI (LOWESS)', zorder=1, rasterized=True
            )
        # —— 坐标轴与样式（放大字号） ——
        ax.set_xlabel(str(feature_to_plot).capitalize(), fontsize=FS_LABEL)
        ax.set_ylabel("SHAP value", fontsize=FS_LABEL)
        ax.tick_params(axis='both', which='major', labelsize=FS_TICK)
        for sp in ['top', 'right', 'left', 'bottom']:
            ax.spines[sp].set_linewidth(1.6)
        # —— 图例（放大字号） ——
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(loc='upper left', fontsize=FS_LEGEND,
                      frameon=True, facecolor='white',
                      framealpha=0.75, edgecolor='lightgray')

        # —— R² 角标（放大字号） ——
        ax.text(0.97, 0.03, f"$R^2_{{LOWESS}}$ = {r2_lowess:.2f}",
                transform=ax.transAxes, fontsize=FS_ANN,
                ha='right', va='bottom',
                bbox=dict(boxstyle='round,pad=0.35', fc='wheat', alpha=0.7))

        # —— 仅在最后一个子图上加颜色条（放大 label 与 ticks） ——
        if idx == len(features) - 1:
            cbar = fig.colorbar(sc, ax=ax, orientation='vertical', fraction=0.045, pad=0.02)
            cbar.set_label('Feature Value', rotation=270, labelpad=14, fontsize=FS_CBAR_L)
            cbar.outline.set_visible(False)
            cbar.ax.tick_params(labelsize=FS_CBAR_T)
            if len(X_data) > 0:
                cbar.set_ticks([X_data.min(), X_data.max()])
                cbar.set_ticklabels(['Low', 'High'])
            else:
                cbar.set_ticks([])
    # —— 隐藏多余子图格 ——
    for i in range(len(features), len(axes)):
        axes[i].axis('off'
    # —— 布局：给大字号预留空间 ——
    plt.tight_layout(rect=[0, 0.03, 0.92, 0.98])
    # —— 导出（优先使用 300dpi；若仍内存紧张，可尝试去掉 tight）——
    if save_as_pdf:
        if use_tight:
            plt.savefig(pdf_path, format='pdf', bbox_inches='tight', pad_inches=0.05, dpi=dpi)
        else:
            plt.savefig(pdf_path, format='pdf', dpi=dpi)

    plt.show()

#variable order
features = ['Gnipc','Gdpc15','Gfcf','Hhfce','EnImp','Relec','EnInt','Fossil','CO2int','Recons','Rnd','Htexp','Pop','Popd','Urbpop','Eleca','Coalr','Gasr','Oilr'
]
plot_lowess_with_ci(
    X_test, shap_values_df, features,
    ncols=4, nrows=5,
    n_bootstraps=80,        # 如仍偏慢/吃内存，可降到 50 或 30
    save_as_pdf=True,
    pdf_path="RCC_lowess_total.pdf",
    dpi=400,                # 如仍 MemoryError，可改为 200
    use_tight=True          # 如仍 MemoryError，改为 False 再试
)
